﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Button_Remote_RefreshPath = New System.Windows.Forms.Button()
        Me.DataGridView_FileViewer = New System.Windows.Forms.DataGridView()
        Me.Filename = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Type = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Size = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ModifiedDate = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button_Remote_Navigation_Forward = New System.Windows.Forms.Button()
        Me.Button_Remote_Navigation_Back = New System.Windows.Forms.Button()
        Me.ProgressBar_SFTPStatus = New System.Windows.Forms.ProgressBar()
        Me.ComboBox_RemotePath = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.FileToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.AboutToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.TextBox_SFTP_Port = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox_SFTP_Password = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.TextBox_SFTP_Username = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.TextBox_SFTP_Host = New System.Windows.Forms.TextBox()
        Me.Button_Connect = New System.Windows.Forms.Button()
        Me.Panel3 = New System.Windows.Forms.Panel()
        Me.Panel4 = New System.Windows.Forms.Panel()
        Me.Button_SFTP_Download = New System.Windows.Forms.Button()
        Me.Button_SFTP_Upload = New System.Windows.Forms.Button()
        Me.Panel5 = New System.Windows.Forms.Panel()
        Me.Button_Status_Cancel = New System.Windows.Forms.Button()
        Me.Label_Status_Value = New System.Windows.Forms.Label()
        Me.Label_Status = New System.Windows.Forms.Label()
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.CheckBox_SFTP_DownloadToLocalPath = New System.Windows.Forms.CheckBox()
        Me.Button_SFTP_DownloadSelectAll = New System.Windows.Forms.Button()
        Me.Panel6 = New System.Windows.Forms.Panel()
        Me.ProgressBar_LocalStatus = New System.Windows.Forms.ProgressBar()
        Me.DataGridView_FileViewerLocal = New System.Windows.Forms.DataGridView()
        Me.LocalFilename = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LocalType = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LocalSize = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.LocalModified = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Button_Local_Navigation_Forward = New System.Windows.Forms.Button()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.ComboBox_LocalPath = New System.Windows.Forms.ComboBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Button_Local_RefreshPath = New System.Windows.Forms.Button()
        Me.Button_Local_Navigation_Back = New System.Windows.Forms.Button()
        Me.Button_Local_Browse = New System.Windows.Forms.Button()
        CType(Me.DataGridView_FileViewer, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel1.SuspendLayout()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        Me.Panel6.SuspendLayout()
        CType(Me.DataGridView_FileViewerLocal, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button_Remote_RefreshPath
        '
        Me.Button_Remote_RefreshPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Remote_RefreshPath.Location = New System.Drawing.Point(426, 28)
        Me.Button_Remote_RefreshPath.Name = "Button_Remote_RefreshPath"
        Me.Button_Remote_RefreshPath.Size = New System.Drawing.Size(61, 23)
        Me.Button_Remote_RefreshPath.TabIndex = 0
        Me.Button_Remote_RefreshPath.Text = "Refresh"
        Me.Button_Remote_RefreshPath.UseVisualStyleBackColor = True
        '
        'DataGridView_FileViewer
        '
        Me.DataGridView_FileViewer.AllowUserToAddRows = False
        Me.DataGridView_FileViewer.AllowUserToDeleteRows = False
        Me.DataGridView_FileViewer.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView_FileViewer.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView_FileViewer.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Filename, Me.Type, Me.Size, Me.ModifiedDate})
        Me.DataGridView_FileViewer.Location = New System.Drawing.Point(3, 54)
        Me.DataGridView_FileViewer.Name = "DataGridView_FileViewer"
        Me.DataGridView_FileViewer.ReadOnly = True
        Me.DataGridView_FileViewer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect
        Me.DataGridView_FileViewer.Size = New System.Drawing.Size(484, 457)
        Me.DataGridView_FileViewer.TabIndex = 1
        '
        'Filename
        '
        Me.Filename.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Filename.HeaderText = "File Name"
        Me.Filename.Name = "Filename"
        Me.Filename.ReadOnly = True
        Me.Filename.Width = 79
        '
        'Type
        '
        Me.Type.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.Type.HeaderText = "Type"
        Me.Type.Name = "Type"
        Me.Type.ReadOnly = True
        '
        'Size
        '
        Me.Size.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.Size.HeaderText = "Size (KB)"
        Me.Size.Name = "Size"
        Me.Size.ReadOnly = True
        Me.Size.Width = 75
        '
        'ModifiedDate
        '
        Me.ModifiedDate.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.ModifiedDate.HeaderText = "Modified Date"
        Me.ModifiedDate.Name = "ModifiedDate"
        Me.ModifiedDate.ReadOnly = True
        Me.ModifiedDate.Width = 98
        '
        'Button_Remote_Navigation_Forward
        '
        Me.Button_Remote_Navigation_Forward.Location = New System.Drawing.Point(36, 4)
        Me.Button_Remote_Navigation_Forward.Name = "Button_Remote_Navigation_Forward"
        Me.Button_Remote_Navigation_Forward.Size = New System.Drawing.Size(28, 20)
        Me.Button_Remote_Navigation_Forward.TabIndex = 9
        Me.Button_Remote_Navigation_Forward.Text = ">"
        Me.Button_Remote_Navigation_Forward.UseVisualStyleBackColor = True
        '
        'Button_Remote_Navigation_Back
        '
        Me.Button_Remote_Navigation_Back.Location = New System.Drawing.Point(7, 4)
        Me.Button_Remote_Navigation_Back.Name = "Button_Remote_Navigation_Back"
        Me.Button_Remote_Navigation_Back.Size = New System.Drawing.Size(28, 20)
        Me.Button_Remote_Navigation_Back.TabIndex = 7
        Me.Button_Remote_Navigation_Back.Text = "<"
        Me.Button_Remote_Navigation_Back.UseVisualStyleBackColor = True
        '
        'ProgressBar_SFTPStatus
        '
        Me.ProgressBar_SFTPStatus.Location = New System.Drawing.Point(9, 26)
        Me.ProgressBar_SFTPStatus.Name = "ProgressBar_SFTPStatus"
        Me.ProgressBar_SFTPStatus.Size = New System.Drawing.Size(53, 4)
        Me.ProgressBar_SFTPStatus.TabIndex = 8
        '
        'ComboBox_RemotePath
        '
        Me.ComboBox_RemotePath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox_RemotePath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.ComboBox_RemotePath.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox_RemotePath.FormattingEnabled = True
        Me.ComboBox_RemotePath.Location = New System.Drawing.Point(74, 3)
        Me.ComboBox_RemotePath.Name = "ComboBox_RemotePath"
        Me.ComboBox_RemotePath.Size = New System.Drawing.Size(273, 21)
        Me.ComboBox_RemotePath.TabIndex = 7
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(0, 7)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(72, 13)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Remote Path:"
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Transparent
        Me.MenuStrip1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.FileToolStripMenuItem, Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(1000, 29)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'FileToolStripMenuItem
        '
        Me.FileToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ExitToolStripMenuItem})
        Me.FileToolStripMenuItem.Name = "FileToolStripMenuItem"
        Me.FileToolStripMenuItem.Size = New System.Drawing.Size(37, 25)
        Me.FileToolStripMenuItem.Text = "File"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(93, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.AboutToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 25)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'AboutToolStripMenuItem
        '
        Me.AboutToolStripMenuItem.Name = "AboutToolStripMenuItem"
        Me.AboutToolStripMenuItem.Size = New System.Drawing.Size(107, 22)
        Me.AboutToolStripMenuItem.Text = "About"
        '
        'Panel2
        '
        Me.Panel2.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.TextBox_SFTP_Port)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Controls.Add(Me.TextBox_SFTP_Password)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.TextBox_SFTP_Username)
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.TextBox_SFTP_Host)
        Me.Panel2.Controls.Add(Me.Button_Connect)
        Me.Panel2.Location = New System.Drawing.Point(6, 7)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(987, 23)
        Me.Panel2.TabIndex = 4
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(791, 5)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(29, 13)
        Me.Label5.TabIndex = 7
        Me.Label5.Text = "Port:"
        '
        'TextBox_SFTP_Port
        '
        Me.TextBox_SFTP_Port.Location = New System.Drawing.Point(826, 1)
        Me.TextBox_SFTP_Port.Name = "TextBox_SFTP_Port"
        Me.TextBox_SFTP_Port.Size = New System.Drawing.Size(52, 20)
        Me.TextBox_SFTP_Port.TabIndex = 6
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(535, 5)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(56, 13)
        Me.Label4.TabIndex = 5
        Me.Label4.Text = "Password:"
        '
        'TextBox_SFTP_Password
        '
        Me.TextBox_SFTP_Password.Location = New System.Drawing.Point(599, 1)
        Me.TextBox_SFTP_Password.Name = "TextBox_SFTP_Password"
        Me.TextBox_SFTP_Password.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.TextBox_SFTP_Password.Size = New System.Drawing.Size(175, 20)
        Me.TextBox_SFTP_Password.TabIndex = 4
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(280, 5)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(58, 13)
        Me.Label3.TabIndex = 3
        Me.Label3.Text = "Username:"
        '
        'TextBox_SFTP_Username
        '
        Me.TextBox_SFTP_Username.Location = New System.Drawing.Point(344, 1)
        Me.TextBox_SFTP_Username.Name = "TextBox_SFTP_Username"
        Me.TextBox_SFTP_Username.Size = New System.Drawing.Size(175, 20)
        Me.TextBox_SFTP_Username.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(75, 5)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(32, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Host:"
        '
        'TextBox_SFTP_Host
        '
        Me.TextBox_SFTP_Host.Location = New System.Drawing.Point(113, 1)
        Me.TextBox_SFTP_Host.Name = "TextBox_SFTP_Host"
        Me.TextBox_SFTP_Host.Size = New System.Drawing.Size(160, 20)
        Me.TextBox_SFTP_Host.TabIndex = 0
        Me.TextBox_SFTP_Host.Text = "SFTP://"
        '
        'Button_Connect
        '
        Me.Button_Connect.Location = New System.Drawing.Point(0, -1)
        Me.Button_Connect.Name = "Button_Connect"
        Me.Button_Connect.Size = New System.Drawing.Size(61, 23)
        Me.Button_Connect.TabIndex = 0
        Me.Button_Connect.Text = "Test"
        Me.Button_Connect.UseVisualStyleBackColor = True
        '
        'Panel3
        '
        Me.Panel3.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel3.BackColor = System.Drawing.SystemColors.ControlLight
        Me.Panel3.Controls.Add(Me.Panel2)
        Me.Panel3.Location = New System.Drawing.Point(0, 28)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(1000, 36)
        Me.Panel3.TabIndex = 5
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.Panel4.Controls.Add(Me.MenuStrip1)
        Me.Panel4.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel4.Location = New System.Drawing.Point(0, 0)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(1000, 29)
        Me.Panel4.TabIndex = 6
        '
        'Button_SFTP_Download
        '
        Me.Button_SFTP_Download.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_SFTP_Download.Location = New System.Drawing.Point(412, 517)
        Me.Button_SFTP_Download.Name = "Button_SFTP_Download"
        Me.Button_SFTP_Download.Size = New System.Drawing.Size(75, 23)
        Me.Button_SFTP_Download.TabIndex = 0
        Me.Button_SFTP_Download.Text = "Download"
        Me.Button_SFTP_Download.UseVisualStyleBackColor = True
        '
        'Button_SFTP_Upload
        '
        Me.Button_SFTP_Upload.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_SFTP_Upload.Location = New System.Drawing.Point(404, 517)
        Me.Button_SFTP_Upload.Name = "Button_SFTP_Upload"
        Me.Button_SFTP_Upload.Size = New System.Drawing.Size(75, 23)
        Me.Button_SFTP_Upload.TabIndex = 1
        Me.Button_SFTP_Upload.Text = "Upload"
        Me.Button_SFTP_Upload.UseVisualStyleBackColor = True
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.Gainsboro
        Me.Panel5.Controls.Add(Me.Button_Status_Cancel)
        Me.Panel5.Controls.Add(Me.Label_Status_Value)
        Me.Panel5.Controls.Add(Me.Label_Status)
        Me.Panel5.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.Panel5.Location = New System.Drawing.Point(0, 620)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(1000, 29)
        Me.Panel5.TabIndex = 9
        '
        'Button_Status_Cancel
        '
        Me.Button_Status_Cancel.BackColor = System.Drawing.Color.Firebrick
        Me.Button_Status_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button_Status_Cancel.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button_Status_Cancel.ForeColor = System.Drawing.Color.White
        Me.Button_Status_Cancel.Location = New System.Drawing.Point(6, 3)
        Me.Button_Status_Cancel.Name = "Button_Status_Cancel"
        Me.Button_Status_Cancel.Size = New System.Drawing.Size(25, 22)
        Me.Button_Status_Cancel.TabIndex = 2
        Me.Button_Status_Cancel.Text = "X"
        Me.Button_Status_Cancel.UseVisualStyleBackColor = False
        '
        'Label_Status_Value
        '
        Me.Label_Status_Value.AutoSize = True
        Me.Label_Status_Value.Location = New System.Drawing.Point(76, 8)
        Me.Label_Status_Value.Name = "Label_Status_Value"
        Me.Label_Status_Value.Size = New System.Drawing.Size(24, 13)
        Me.Label_Status_Value.TabIndex = 1
        Me.Label_Status_Value.Text = "Idle"
        '
        'Label_Status
        '
        Me.Label_Status.AutoSize = True
        Me.Label_Status.Location = New System.Drawing.Point(36, 8)
        Me.Label_Status.Name = "Label_Status"
        Me.Label_Status.Size = New System.Drawing.Size(40, 13)
        Me.Label_Status.TabIndex = 0
        Me.Label_Status.Text = "Status:"
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SplitContainer1.Location = New System.Drawing.Point(12, 70)
        Me.SplitContainer1.Name = "SplitContainer1"
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.Controls.Add(Me.CheckBox_SFTP_DownloadToLocalPath)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_SFTP_DownloadSelectAll)
        Me.SplitContainer1.Panel1.Controls.Add(Me.ProgressBar_SFTPStatus)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_Remote_Navigation_Forward)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_Remote_Navigation_Back)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Panel6)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_SFTP_Download)
        Me.SplitContainer1.Panel1.Controls.Add(Me.DataGridView_FileViewer)
        Me.SplitContainer1.Panel1.Controls.Add(Me.Button_Remote_RefreshPath)
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_Local_Browse)
        Me.SplitContainer1.Panel2.Controls.Add(Me.ProgressBar_LocalStatus)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_SFTP_Upload)
        Me.SplitContainer1.Panel2.Controls.Add(Me.DataGridView_FileViewerLocal)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_Local_Navigation_Forward)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Panel1)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_Local_RefreshPath)
        Me.SplitContainer1.Panel2.Controls.Add(Me.Button_Local_Navigation_Back)
        Me.SplitContainer1.Size = New System.Drawing.Size(976, 544)
        Me.SplitContainer1.SplitterDistance = 490
        Me.SplitContainer1.TabIndex = 10
        '
        'CheckBox_SFTP_DownloadToLocalPath
        '
        Me.CheckBox_SFTP_DownloadToLocalPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.CheckBox_SFTP_DownloadToLocalPath.AutoSize = True
        Me.CheckBox_SFTP_DownloadToLocalPath.Checked = True
        Me.CheckBox_SFTP_DownloadToLocalPath.CheckState = System.Windows.Forms.CheckState.Checked
        Me.CheckBox_SFTP_DownloadToLocalPath.Location = New System.Drawing.Point(266, 521)
        Me.CheckBox_SFTP_DownloadToLocalPath.Name = "CheckBox_SFTP_DownloadToLocalPath"
        Me.CheckBox_SFTP_DownloadToLocalPath.Size = New System.Drawing.Size(140, 17)
        Me.CheckBox_SFTP_DownloadToLocalPath.TabIndex = 11
        Me.CheckBox_SFTP_DownloadToLocalPath.Text = "Download to Local Path"
        Me.CheckBox_SFTP_DownloadToLocalPath.UseVisualStyleBackColor = True
        '
        'Button_SFTP_DownloadSelectAll
        '
        Me.Button_SFTP_DownloadSelectAll.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Button_SFTP_DownloadSelectAll.Location = New System.Drawing.Point(3, 517)
        Me.Button_SFTP_DownloadSelectAll.Name = "Button_SFTP_DownloadSelectAll"
        Me.Button_SFTP_DownloadSelectAll.Size = New System.Drawing.Size(75, 23)
        Me.Button_SFTP_DownloadSelectAll.TabIndex = 10
        Me.Button_SFTP_DownloadSelectAll.Text = "Select All"
        Me.Button_SFTP_DownloadSelectAll.UseVisualStyleBackColor = True
        '
        'Panel6
        '
        Me.Panel6.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel6.Controls.Add(Me.ComboBox_RemotePath)
        Me.Panel6.Controls.Add(Me.Label1)
        Me.Panel6.Location = New System.Drawing.Point(70, 3)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(350, 25)
        Me.Panel6.TabIndex = 0
        '
        'ProgressBar_LocalStatus
        '
        Me.ProgressBar_LocalStatus.Location = New System.Drawing.Point(10, 28)
        Me.ProgressBar_LocalStatus.Name = "ProgressBar_LocalStatus"
        Me.ProgressBar_LocalStatus.Size = New System.Drawing.Size(53, 4)
        Me.ProgressBar_LocalStatus.TabIndex = 14
        '
        'DataGridView_FileViewerLocal
        '
        Me.DataGridView_FileViewerLocal.AllowUserToAddRows = False
        Me.DataGridView_FileViewerLocal.AllowUserToDeleteRows = False
        Me.DataGridView_FileViewerLocal.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
            Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.DataGridView_FileViewerLocal.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView_FileViewerLocal.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.LocalFilename, Me.LocalType, Me.LocalSize, Me.LocalModified})
        Me.DataGridView_FileViewerLocal.Location = New System.Drawing.Point(3, 54)
        Me.DataGridView_FileViewerLocal.MultiSelect = False
        Me.DataGridView_FileViewerLocal.Name = "DataGridView_FileViewerLocal"
        Me.DataGridView_FileViewerLocal.ReadOnly = True
        Me.DataGridView_FileViewerLocal.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.DataGridView_FileViewerLocal.Size = New System.Drawing.Size(476, 457)
        Me.DataGridView_FileViewerLocal.TabIndex = 10
        '
        'LocalFilename
        '
        Me.LocalFilename.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.LocalFilename.HeaderText = "File Name"
        Me.LocalFilename.Name = "LocalFilename"
        Me.LocalFilename.ReadOnly = True
        Me.LocalFilename.Width = 79
        '
        'LocalType
        '
        Me.LocalType.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.Fill
        Me.LocalType.HeaderText = "Type"
        Me.LocalType.Name = "LocalType"
        Me.LocalType.ReadOnly = True
        '
        'LocalSize
        '
        Me.LocalSize.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.LocalSize.HeaderText = "Size (KB)"
        Me.LocalSize.Name = "LocalSize"
        Me.LocalSize.ReadOnly = True
        Me.LocalSize.Width = 75
        '
        'LocalModified
        '
        Me.LocalModified.AutoSizeMode = System.Windows.Forms.DataGridViewAutoSizeColumnMode.AllCells
        Me.LocalModified.HeaderText = "Modified Date"
        Me.LocalModified.Name = "LocalModified"
        Me.LocalModified.ReadOnly = True
        Me.LocalModified.Width = 98
        '
        'Button_Local_Navigation_Forward
        '
        Me.Button_Local_Navigation_Forward.Location = New System.Drawing.Point(36, 5)
        Me.Button_Local_Navigation_Forward.Name = "Button_Local_Navigation_Forward"
        Me.Button_Local_Navigation_Forward.Size = New System.Drawing.Size(28, 20)
        Me.Button_Local_Navigation_Forward.TabIndex = 15
        Me.Button_Local_Navigation_Forward.Text = ">"
        Me.Button_Local_Navigation_Forward.UseVisualStyleBackColor = True
        '
        'Panel1
        '
        Me.Panel1.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Panel1.Controls.Add(Me.ComboBox_LocalPath)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Location = New System.Drawing.Point(71, 2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(341, 25)
        Me.Panel1.TabIndex = 11
        '
        'ComboBox_LocalPath
        '
        Me.ComboBox_LocalPath.Anchor = CType(((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Left) _
            Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.ComboBox_LocalPath.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend
        Me.ComboBox_LocalPath.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.ComboBox_LocalPath.FormattingEnabled = True
        Me.ComboBox_LocalPath.Location = New System.Drawing.Point(74, 3)
        Me.ComboBox_LocalPath.Name = "ComboBox_LocalPath"
        Me.ComboBox_LocalPath.Size = New System.Drawing.Size(264, 21)
        Me.ComboBox_LocalPath.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(0, 7)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(61, 13)
        Me.Label6.TabIndex = 1
        Me.Label6.Text = "Local Path:"
        '
        'Button_Local_RefreshPath
        '
        Me.Button_Local_RefreshPath.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Local_RefreshPath.Location = New System.Drawing.Point(418, 28)
        Me.Button_Local_RefreshPath.Name = "Button_Local_RefreshPath"
        Me.Button_Local_RefreshPath.Size = New System.Drawing.Size(61, 23)
        Me.Button_Local_RefreshPath.TabIndex = 12
        Me.Button_Local_RefreshPath.Text = "Refresh"
        Me.Button_Local_RefreshPath.UseVisualStyleBackColor = True
        '
        'Button_Local_Navigation_Back
        '
        Me.Button_Local_Navigation_Back.Location = New System.Drawing.Point(7, 5)
        Me.Button_Local_Navigation_Back.Name = "Button_Local_Navigation_Back"
        Me.Button_Local_Navigation_Back.Size = New System.Drawing.Size(28, 20)
        Me.Button_Local_Navigation_Back.TabIndex = 13
        Me.Button_Local_Navigation_Back.Text = "<"
        Me.Button_Local_Navigation_Back.UseVisualStyleBackColor = True
        '
        'Button_Local_Browse
        '
        Me.Button_Local_Browse.Anchor = CType((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.Button_Local_Browse.Location = New System.Drawing.Point(418, 3)
        Me.Button_Local_Browse.Name = "Button_Local_Browse"
        Me.Button_Local_Browse.Size = New System.Drawing.Size(61, 23)
        Me.Button_Local_Browse.TabIndex = 16
        Me.Button_Local_Browse.Text = "Browse"
        Me.Button_Local_Browse.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1000, 649)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Panel3)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.MinimumSize = New System.Drawing.Size(913, 400)
        Me.Name = "Form1"
        Me.ShowIcon = False
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SFTP Module"
        CType(Me.DataGridView_FileViewer, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.Panel3.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel4.PerformLayout()
        Me.Panel5.ResumeLayout(False)
        Me.Panel5.PerformLayout()
        Me.SplitContainer1.Panel1.ResumeLayout(False)
        Me.SplitContainer1.Panel1.PerformLayout()
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel6.PerformLayout()
        CType(Me.DataGridView_FileViewerLocal, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Button_Remote_RefreshPath As Button
    Friend WithEvents DataGridView_FileViewer As DataGridView
    Friend WithEvents Label1 As Label
    Friend WithEvents MenuStrip1 As MenuStrip
    Friend WithEvents FileToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents HelpToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents AboutToolStripMenuItem As ToolStripMenuItem
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label5 As Label
    Friend WithEvents TextBox_SFTP_Port As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents TextBox_SFTP_Password As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TextBox_SFTP_Username As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents TextBox_SFTP_Host As TextBox
    Friend WithEvents Button_Connect As Button
    Friend WithEvents Panel3 As Panel
    Friend WithEvents Panel4 As Panel
    Friend WithEvents ComboBox_RemotePath As ComboBox
    Friend WithEvents ProgressBar_SFTPStatus As ProgressBar
    Friend WithEvents Button_Remote_Navigation_Forward As Button
    Friend WithEvents Button_Remote_Navigation_Back As Button
    Friend WithEvents Button_SFTP_Download As Button
    Friend WithEvents Button_SFTP_Upload As Button
    Friend WithEvents Panel5 As Panel
    Friend WithEvents Label_Status_Value As Label
    Friend WithEvents Label_Status As Label
    Friend WithEvents Button_Status_Cancel As Button
    Friend WithEvents Filename As DataGridViewTextBoxColumn
    Friend WithEvents Type As DataGridViewTextBoxColumn
    Friend WithEvents Size As DataGridViewTextBoxColumn
    Friend WithEvents ModifiedDate As DataGridViewTextBoxColumn
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents DataGridView_FileViewerLocal As DataGridView
    Friend WithEvents Panel6 As Panel
    Friend WithEvents ProgressBar_LocalStatus As ProgressBar
    Friend WithEvents Button_Local_Navigation_Forward As Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents ComboBox_LocalPath As ComboBox
    Friend WithEvents Label6 As Label
    Friend WithEvents Button_Local_RefreshPath As Button
    Friend WithEvents Button_Local_Navigation_Back As Button
    Friend WithEvents Button_SFTP_DownloadSelectAll As Button
    Friend WithEvents LocalFilename As DataGridViewTextBoxColumn
    Friend WithEvents LocalType As DataGridViewTextBoxColumn
    Friend WithEvents LocalSize As DataGridViewTextBoxColumn
    Friend WithEvents LocalModified As DataGridViewTextBoxColumn
    Friend WithEvents CheckBox_SFTP_DownloadToLocalPath As CheckBox
    Friend WithEvents Button_Local_Browse As Button
End Class
