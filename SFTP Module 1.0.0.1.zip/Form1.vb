﻿Imports System.ComponentModel
Imports System.IO
Imports System.Threading
Imports Renci.SshNet
Imports System.Linq
Imports Microsoft.WindowsAPICodePack.Dialogs



Public Class Form1


    Private NavigationStack_Remote As New List(Of String)
    Private CurrentNavigationIndex_Remote As Integer = -1

    Private NavigationStack_Local As New List(Of String)
    Private CurrentNavigationIndex_Local As Integer = -1

    Private cts As Threading.CancellationTokenSource

    Dim host As String = "sftp://server"
    Dim username As String = "joe.bloggs"
    Dim password As String = "Password1234!"
    Dim port As Integer = 22




    ' FORM LOAD
    ' ===============================
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        UpdateUITextboxes_HardCodedDetails()
        CheckIfRemotePathEmpty()
        CheckIfLocalPathEmpty()
        NavigateToPath_Local(ComboBox_LocalPath.Text)
    End Sub




    Private Sub UpdateUITextboxes_HardCodedDetails()
        TextBox_SFTP_Host.Text = host
        TextBox_SFTP_Username.Text = username
        TextBox_SFTP_Password.Text = password
        TextBox_SFTP_Port.Text = port
    End Sub







    ' MENU STRIP
    ' ===============================

    Private Sub ExitToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Me.Close()
    End Sub



    Private Sub AboutToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles AboutToolStripMenuItem.Click
        Dim aboutText As String = "SFTP Module - Version " & ModuleVersion_SFTP & Environment.NewLine & Environment.NewLine &
            "This is a single, portable VB.NET module for integrating asynchronous SFTP access into your applications." & Environment.NewLine &
            Environment.NewLine &
            "Requirements:" & Environment.NewLine &
            "• .NET Framework 4.7.2 or higher" & Environment.NewLine &
            "• SSH.NET library v2020.0.1 (Renci.SshNet, via NuGet)" & Environment.NewLine &
            Environment.NewLine &
            "Features:" & Environment.NewLine &
            "• Asynchronous connection to SFTP servers" & Environment.NewLine &
            "• File browsing and navigation with directory history (back/forward)" & Environment.NewLine &
            "• Download multiple files (sequentially) with progress tracking" & Environment.NewLine &
            "• Upload single files (use .zip to bundle multiple files)" & Environment.NewLine &
            "• Auto-reconnect on minor or short network interruptions" & Environment.NewLine &
            "• Detailed progress display including:" & Environment.NewLine &
            "   - Estimated time remaining" & Environment.NewLine &
            "   - Elapsed time" & Environment.NewLine &
            "   - Bytes transferred and total size" & Environment.NewLine &
            "   - Current transfer rate" & Environment.NewLine &
            "• Ability to cancel a download in progress using cancelationTokens"
        MessageBox.Show(aboutText, "About SFTP Module", MessageBoxButtons.OK, MessageBoxIcon.Information)
    End Sub








    ' MENU STRIP
    ' ===============================

    Private Async Sub Button_Connect_Click(sender As Object, e As EventArgs) Handles Button_Connect.Click
        ProgressBar_SFTPStatus.Style = ProgressBarStyle.Marquee
        Dim testResultString As String = Await SFTP_TestConnection(TextBox_SFTP_Host.Text, TextBox_SFTP_Username.Text, TextBox_SFTP_Password.Text, TextBox_SFTP_Port.Text)
        ProgressBar_SFTPStatus.Style = ProgressBarStyle.Blocks
        ProgressBar_SFTPStatus.Value = 0
        If testResultString.ToLower().Contains("error") = False OrElse testResultString.ToLower().Contains("fail") = False Then
            MessageBox.Show("Test Connection Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show(testResultString, "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub







    Private Async Sub Button_Remote_Navigation_Back_Click(sender As Object, e As EventArgs) Handles Button_Remote_Navigation_Back.Click
        If CurrentNavigationIndex_Remote > 0 Then
            CurrentNavigationIndex_Remote -= 1
            Await NavigateToPath_Remote(NavigationStack_Remote(CurrentNavigationIndex_Remote), triggeredByNavigationButton:=True)
        End If
    End Sub


    Private Async Sub Button_Remote_Navigation_Forward_Click(sender As Object, e As EventArgs) Handles Button_Remote_Navigation_Forward.Click
        If CurrentNavigationIndex_Remote < NavigationStack_Remote.Count - 1 Then
            CurrentNavigationIndex_Remote += 1
            Await NavigateToPath_Remote(NavigationStack_Remote(CurrentNavigationIndex_Remote), triggeredByNavigationButton:=True)
        End If
    End Sub





    Private Async Sub ComboBox_RemotePath_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_RemotePath.SelectedIndexChanged
        Await GetFilesFromSFTPAsync()
    End Sub



    Private Async Sub ComboBox_RemotePath_KeyDown(sender As Object, e As KeyEventArgs) Handles ComboBox_RemotePath.KeyDown
        If e.KeyCode = Keys.Enter Then
            e.Handled = True
            e.SuppressKeyPress = True

            ProgressBar_SFTPStatus.Style = ProgressBarStyle.Marquee
            Await NavigateToPath_Remote(ComboBox_RemotePath.Text)
            ProgressBar_SFTPStatus.Style = ProgressBarStyle.Blocks
            ProgressBar_SFTPStatus.Value = 0
        End If
    End Sub


    Private Sub ComboBox_RemotePath_Validating(sender As Object, e As CancelEventArgs) Handles ComboBox_RemotePath.Validating
        CheckIfRemotePathEmpty()
    End Sub






    Private Async Sub Button_Remote_RefreshPath_Click(sender As Object, e As EventArgs) Handles Button_Remote_RefreshPath.Click
        ProgressBar_SFTPStatus.Style = ProgressBarStyle.Marquee
        Await NavigateToPath_Remote(ComboBox_RemotePath.Text)
        ProgressBar_SFTPStatus.Style = ProgressBarStyle.Blocks
        ProgressBar_SFTPStatus.Value = 0
    End Sub











    Private Sub DataGridView_FileViewer_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_FileViewer.CellContentClick

    End Sub



    Private Async Sub DataGridView_FileViewer_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_FileViewer.CellDoubleClick
        If e.RowIndex < 0 Then Exit Sub

        Dim selectedRow As DataGridViewRow = DataGridView_FileViewer.Rows(e.RowIndex)
        Dim itemType As String = selectedRow.Cells("type").Value.ToString()
        Dim fileName As String = selectedRow.Cells("filename").Value.ToString()

        ' Folder - Open It
        If itemType.Equals("Directory", StringComparison.OrdinalIgnoreCase) Then
            Dim currentPath As String = ComboBox_RemotePath.Text.TrimEnd("/"c)
            Dim newPath As String = $"{currentPath}/{fileName}"
            ComboBox_RemotePath.Text = newPath

            ProgressBar_SFTPStatus.Style = ProgressBarStyle.Marquee
            Await NavigateToPath_Remote(newPath)
            ProgressBar_SFTPStatus.Style = ProgressBarStyle.Blocks
            ProgressBar_SFTPStatus.Value = 0
        End If

        ' If File - Download it
        If itemType.Equals("File", StringComparison.OrdinalIgnoreCase) Then
            Await DownloadSelectedFiles()
        End If

    End Sub







    Private Sub CheckIfRemotePathEmpty()
        If String.IsNullOrWhiteSpace(ComboBox_RemotePath.Text) Then
            ComboBox_RemotePath.Text = "/"
        End If
    End Sub


    Private Sub CheckIfLocalPathEmpty()
        If String.IsNullOrWhiteSpace(ComboBox_LocalPath.Text) Then
            ComboBox_LocalPath.Text = "C:\"
        End If
    End Sub







    Private Async Function GetFilesFromSFTPAsync() As Task
        Dim remotePath As String = ComboBox_RemotePath.Text
        Dim files As List(Of SftpFileItem) = Await SFTP_ListFilesAsync(host, username, password, port, remotePath)   ' Get files from SFTP
        DataGridView_FileViewer.Rows.Clear()
        For Each file In files
            DataGridView_FileViewer.Rows.Add(file.SFTPFileName, file.SFTPFileType, file.SFTPFileSizeKB & "KB", file.SFTPFileModified)
        Next
    End Function



    Private Async Function GetFileFromLocalAsync() As Task
        Dim path As String = ComboBox_LocalPath.Text

        If String.IsNullOrWhiteSpace(path) OrElse Not Directory.Exists(path) Then
            MessageBox.Show("Invalid directory path.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        DataGridView_FileViewerLocal.Rows.Clear()

        Try
            ' Fetch files and non-hidden directories asynchronously
            Dim entries = Await Task.Run(Function()
                                             ' Get non-hidden directories
                                             Dim folders = Directory.GetDirectories(path).
                                         Where(Function(d)
                                                   Dim attr = File.GetAttributes(d)
                                                   Return (attr And FileAttributes.Hidden) = 0
                                               End Function)

                                             ' Get all files (hidden files allowed)
                                             Dim files = Directory.GetFiles(path)

                                             Return folders.Concat(files).ToList()
                                         End Function)

            For Each entry In entries
                If Directory.Exists(entry) Then
                    ' It's a visible folder
                    Dim dirInfo As New DirectoryInfo(entry)
                    DataGridView_FileViewerLocal.Rows.Add(
                    dirInfo.Name,
                    "Folder",
                    "",
                    dirInfo.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
                )
                ElseIf File.Exists(entry) Then
                    ' It's a file
                    Dim fileInfo As New FileInfo(entry)
                    Dim extension = fileInfo.Extension.ToLower()

                    ' Skip .sys and .dmp files
                    If extension = ".sys" OrElse extension = ".dmp" OrElse extension = ".tmp" Then
                        Continue For
                    End If

                    ' Remove the leading dot from extension for display (optional)
                    If extension.StartsWith(".") Then extension = extension.Substring(1)

                    DataGridView_FileViewerLocal.Rows.Add(
                    fileInfo.Name,
                    extension,
                    fileInfo.Length.ToString("N0"),
                    fileInfo.LastWriteTime.ToString("yyyy-MM-dd HH:mm:ss")
                )
                End If
            Next
        Catch ex As Exception
            MessageBox.Show("Error reading directory: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Function












    Private Sub AddPathToComboBoxHistory_Remote(path As String)
        Dim cleanPath As String = path.Trim()
        If cleanPath <> "" Then
            ' Remove if it already exists to keep list unique
            If ComboBox_RemotePath.Items.Contains(cleanPath) Then
                ComboBox_RemotePath.Items.Remove(cleanPath)
            End If

            ComboBox_RemotePath.Items.Insert(0, cleanPath)
            ComboBox_RemotePath.Text = cleanPath
        End If
    End Sub



    Private Sub AddPathToComboBoxHistory_Local(path As String)
        Dim cleanPath As String = path.Trim()
        If cleanPath <> "" Then
            ' Remove if it already exists to keep list unique
            If ComboBox_LocalPath.Items.Contains(cleanPath) Then
                ComboBox_LocalPath.Items.Remove(cleanPath)
            End If

            ComboBox_LocalPath.Items.Insert(0, cleanPath)
            ComboBox_LocalPath.Text = cleanPath
        End If
    End Sub





    Private Async Function NavigateToPath_Remote(path As String, Optional triggeredByNavigationButton As Boolean = False) As Task

        If Await CheckInternetConnection() = False Then
            Return
        End If

        Dim cleanPath As String = path.Trim()
        If cleanPath = "" Then Exit Function

        ComboBox_RemotePath.Text = cleanPath

        ' Prevent duplicate if same as current
        If CurrentNavigationIndex_Remote >= 0 AndAlso NavigationStack_Remote(CurrentNavigationIndex_Remote) = cleanPath Then
            Return
        End If

        ' If navigating manually (not with buttons), discard forward history
        If Not triggeredByNavigationButton AndAlso CurrentNavigationIndex_Remote < NavigationStack_Remote.Count - 1 Then
            NavigationStack_Remote = NavigationStack_Remote.Take(CurrentNavigationIndex_Remote + 1).ToList()
        End If

        ' Add to stack only if not same as last
        If Not triggeredByNavigationButton Then
            If NavigationStack_Remote.Count = 0 OrElse NavigationStack_Remote.Last() <> cleanPath Then
                NavigationStack_Remote.Add(cleanPath)
                CurrentNavigationIndex_Remote = NavigationStack_Remote.Count - 1
            End If
        End If

        ComboBox_RemotePath.Text = cleanPath
        AddPathToComboBoxHistory_Remote(cleanPath)
        Await GetFilesFromSFTPAsync()
    End Function




    Private Async Function NavigateToPath_Local(path As String, Optional triggeredByNavigationButton As Boolean = False) As Task

        Dim cleanPath As String = path.Trim()
        If cleanPath = "" Then Exit Function

        ComboBox_LocalPath.Text = cleanPath

        ' Prevent duplicate if same as current
        If CurrentNavigationIndex_Local >= 0 AndAlso NavigationStack_Local(CurrentNavigationIndex_Local) = cleanPath Then
            Return
        End If

        ' If navigating manually (not with buttons), discard forward history
        If Not triggeredByNavigationButton AndAlso CurrentNavigationIndex_Local < NavigationStack_Local.Count - 1 Then
            NavigationStack_Local = NavigationStack_Local.Take(CurrentNavigationIndex_Local + 1).ToList()
        End If

        ' Add to stack only if not same as last
        If Not triggeredByNavigationButton Then
            If NavigationStack_Local.Count = 0 OrElse NavigationStack_Local.Last() <> cleanPath Then
                NavigationStack_Local.Add(cleanPath)
                CurrentNavigationIndex_Local = NavigationStack_Local.Count - 1
            End If
        End If

        ComboBox_LocalPath.Text = cleanPath
        AddPathToComboBoxHistory_Local(cleanPath)
        'Await GetFileFromLocalAsync()
    End Function









    Private Async Sub Button_SFTP_Download_Click(sender As Object, e As EventArgs) Handles Button_SFTP_Download.Click
        Await DownloadSelectedFiles()
    End Sub






    Private Async Sub Button_SFTP_Upload_Click(sender As Object, e As EventArgs) Handles Button_SFTP_Upload.Click

        If Await CheckInternetConnection() = False Then
            Exit Sub
        End If

        ' Ensure a row is selected in the DataGridView
        If DataGridView_FileViewerLocal.SelectedRows.Count = 0 Then
            MessageBox.Show("Please select a file from the list.", "No File Selected", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Get the file name from the selected row
        Dim selectedRow As DataGridViewRow = DataGridView_FileViewerLocal.SelectedRows(0)
        Dim fileName As String = Convert.ToString(selectedRow.Cells("localFilename").Value)

        If String.IsNullOrWhiteSpace(fileName) Then
            MessageBox.Show("Selected file name is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Get local directory from ComboBox
        Dim localFolder As String = ComboBox_LocalPath.Text.Trim()
        If String.IsNullOrWhiteSpace(localFolder) OrElse Not IO.Directory.Exists(localFolder) Then
            MessageBox.Show("Local path is invalid or does not exist.", "Invalid Path", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Build full local file path
        Dim localFilePath As String = IO.Path.Combine(localFolder, fileName)

        If Not IO.File.Exists(localFilePath) Then
            MessageBox.Show("Selected file does not exist at the specified path.", "File Not Found", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End If

        ' Get remote directory
        Dim remoteFolder As String = ComboBox_RemotePath.Text.Trim().TrimEnd("/"c)
        If String.IsNullOrWhiteSpace(remoteFolder) Then
            MessageBox.Show("Remote path is invalid.", "Invalid Remote Path", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        ' Combine remote folder and file name
        Dim remotePath As String = $"{remoteFolder}/{fileName}"



        ProgressBar_SFTPStatus.Style = ProgressBarStyle.Blocks
        ProgressBar_SFTPStatus.Value = 0

        ProgressBar_SFTPStatus.Minimum = 0
        ProgressBar_SFTPStatus.Maximum = 100

        Dim progress = New Progress(Of UploadProgress)(Sub(p)
                                                           Try
                                                               If p.SFTPTotalBytes > 0 Then
                                                                   Dim percent = CInt((p.SFTPBytesSent / p.SFTPTotalBytes) * 100)
                                                                   ProgressBar_SFTPStatus.Value = Math.Min(percent, 100)
                                                                   Label_Status_Value.Text = $"Uploading {fileName}... {percent}% | Speed: {Math.Round(p.SFTPSpeedKbps, 1)} KB/s | Elapsed: {p.SFTPElapsed:hh\:mm\:ss} | ETA: {p.SFTPETA:hh\:mm\:ss}"
                                                               End If
                                                           Catch ex As Exception
                                                               Debug.WriteLine("Progress error: " & ex.Message)
                                                           End Try
                                                       End Sub)

        ' Setup cancellation
        cts = GenerateToken()
        Dim token = cts.Token

        Button_Status_Cancel.Enabled = True

        Dim success = Await SFTP_UploadFileAsync(host, username, password, port, localFilePath, remotePath, progress, cts.Token, AddressOf customCallBack)

        ProgressBar_SFTPStatus.Style = ProgressBarStyle.Blocks
        ProgressBar_SFTPStatus.Value = 0
        Button_Status_Cancel.Enabled = False
        Label_Status_Value.Text = "Idle"

        If success Then
            MessageBox.Show("Upload successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Await GetFilesFromSFTPAsync()
            Await GetFileFromLocalAsync()
        Else
            MessageBox.Show("Upload failed", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

    End Sub




    Private Function GetSelectedFileRow() As DataGridViewRow
        If DataGridView_FileViewer.SelectedCells.Count > 0 Then
            Return DataGridView_FileViewer.Rows(DataGridView_FileViewer.SelectedCells(0).RowIndex)
        ElseIf DataGridView_FileViewer.SelectedRows.Count > 0 Then
            Return DataGridView_FileViewer.SelectedRows(0)
        Else
            Return Nothing
        End If
    End Function





    Private Sub Button_Status_Cancel_Click(sender As Object, e As EventArgs) Handles Button_Status_Cancel.Click

        If cts IsNot Nothing AndAlso Not cts.IsCancellationRequested Then
            Dim answer = MessageBox.Show("CONFIRM:" & vbCrLf & "Cancel Operation in Progress?", "Cancel?", MessageBoxButtons.YesNo, MessageBoxIcon.Warning)
            If answer = vbYes Then
                cts.Cancel()
                Label_Status_Value.Text = "Cancelling download..."
                If cts IsNot Nothing AndAlso Not cts.IsCancellationRequested Then

                End If
            End If

        Else
            MessageBox.Show("NOTE:" & vbCrLf & "Nothing is in progress to Cancel", "Nothing in Progress", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
        Button_SFTP_Download.Enabled = True
    End Sub








    Private Async Function CheckInternetConnection() As Task(Of Boolean)
        ProgressBar_SFTPStatus.Style = ProgressBarStyle.Marquee
        Dim connectionResult As String = Await SFTP_TestConnection(TextBox_SFTP_Host.Text, TextBox_SFTP_Username.Text, TextBox_SFTP_Password.Text, TextBox_SFTP_Port.Text)
        ProgressBar_SFTPStatus.Style = ProgressBarStyle.Blocks
        ProgressBar_SFTPStatus.Value = 0
        If connectionResult.ToLower.Contains("connection succeeded") Then
            'MessageBox.Show("Test Connection Successful", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
            Label_Status_Value.Text = "Connected"
            Return True
        Else
            MessageBox.Show(connectionResult, "Failed", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return False
        End If
    End Function







    Private Async Function DownloadSelectedFiles() As Task

        ' V4
        If Await CheckInternetConnection() = False Then
            Exit Function
        End If

        If DataGridView_FileViewer.Rows.Count = 0 Then
            MessageBox.Show("NOTE:" & vbCrLf & "You're not connected to an SFTP Server yet." & vbCrLf & vbCrLf & "Connect to a remote folder first," & vbCrLf & "then retry a download", "Not Connected", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If

        If DataGridView_FileViewer.SelectedCells.Count = 0 Then
            MessageBox.Show("Please select at least one file to download.", "No Selection", MessageBoxButtons.OK, MessageBoxIcon.Warning)
            Return
        End If


        ' Use a HashSet to avoid duplicate rows
        Dim selectedRows As New HashSet(Of DataGridViewRow)

        Try
            For Each cell As DataGridViewCell In DataGridView_FileViewer.SelectedCells
                selectedRows.Add(cell.OwningRow)
            Next
        Catch ex As Exception
            MessageBox.Show("Error retrieving selected rows: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Return
        End Try

        Dim fileName As String = ""

        ' If only a single row is selected and its as directory - navigate into it, rather than download
        If selectedRows.Count = 1 Then
            Dim itemType As String = ""
            Dim selectedRow As DataGridViewRow = selectedRows(0)
            itemType = selectedRow.Cells("type").Value.ToString()
            fileName = selectedRow.Cells("Filename").Value.ToString()

            If itemType.Equals("Directory", StringComparison.OrdinalIgnoreCase) Then
                Try
                    Dim currentPath As String = ComboBox_RemotePath.Text.TrimEnd("/"c)
                    Dim newPath As String = $"{currentPath}/{Filename}"
                    ComboBox_RemotePath.Text = newPath

                    ProgressBar_SFTPStatus.Style = ProgressBarStyle.Marquee
                    Await NavigateToPath_Remote(newPath)
                    ProgressBar_SFTPStatus.Style = ProgressBarStyle.Blocks
                    ProgressBar_SFTPStatus.Value = 0
                Catch ex As Exception
                    MessageBox.Show("Error navigating into directory: " & ex.Message, "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End Try
                ' Skip Everything else 
                Exit Function
            End If
        End If


        Dim targetFolder As String

        If CheckBox_SFTP_DownloadToLocalPath.Checked = True Then
            targetFolder = ComboBox_LocalPath.Text

        Else
            ' Prompt user to choose folder once
            Dim folderDialog As New FolderBrowserDialog() With {
                .Description = "Select folder to save downloaded files"
            }

            Try
                If folderDialog.ShowDialog() <> DialogResult.OK Then
                    Return
                End If
            Catch ex As Exception
                MessageBox.Show("Error selecting folder: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Return
            End Try

            targetFolder = folderDialog.SelectedPath
        End If


        ' Gather list of files that already exist locally
        Dim filesThatExist As New List(Of String)
        For Each row As DataGridViewRow In selectedRows
            Dim potentialFileName = row.Cells("filename").Value.ToString()
            Dim potentialPath = IO.Path.Combine(targetFolder, potentialFileName)
            If IO.File.Exists(potentialPath) Then
                filesThatExist.Add(potentialFileName)
            End If
        Next

        ' Only ask about overwriting if there are conflicts
        Dim overwriteExisting As DialogResult = DialogResult.None
        Dim suppressPrompts As Boolean = False

        If filesThatExist.Count > 0 Then
            overwriteExisting = MessageBox.Show("Overwrite existing files?", "Overwrite?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)

            If overwriteExisting = DialogResult.Yes Then
                Dim allInOneGo = MessageBox.Show("Suppress Messages?", "Suppress Overwrite Prompts?", MessageBoxButtons.YesNo, MessageBoxIcon.Question)
                suppressPrompts = (allInOneGo = DialogResult.Yes)
            End If
        End If

        ' Setup cancellation
        cts = GenerateToken()
        Dim token = cts.Token

        Button_SFTP_Download.Enabled = False
        Button_Status_Cancel.Enabled = True

        ' Counters
        Dim successCount As Integer = 0
        Dim failCount As Integer = 0
        Dim cancelCount As Integer = 0
        Dim listOfErrorStrings As New List(Of String)

        Dim totalFiles As Integer = selectedRows.Count
        Dim currentIndex As Integer = 0


        ' Loop through selected files
        For Each row As DataGridViewRow In selectedRows
            currentIndex += 1

            If token.IsCancellationRequested Then
                cancelCount += 1
                Exit For
            End If

            Dim remotePath As String
            Dim localPath As String

            Try
                fileName = row.Cells("filename").Value.ToString()
                remotePath = $"{ComboBox_RemotePath.Text.TrimEnd("/")}/{fileName}"
                localPath = IO.Path.Combine(targetFolder, fileName)
            Catch ex As Exception
                MessageBox.Show("Error preparing file paths: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                failCount += 1
                Continue For
            End Try


            Try
                If IO.File.Exists(localPath) Then

                    If overwriteExisting = DialogResult.Yes Then
                        If Not suppressPrompts Then
                            Dim result = MessageBox.Show($"File '{fileName}' already exists. Overwrite?", "File Exists", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question)
                            If result = DialogResult.No Then Continue For
                            If result = DialogResult.Cancel Then
                                cancelCount += 1
                                Exit For
                            End If
                        End If
                        ' Otherwise: silently overwrite
                    ElseIf overwriteExisting = DialogResult.No Then
                        Continue For ' skip existing file
                    End If

                End If
            Catch ex As Exception
                MessageBox.Show("Error checking existing file: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                failCount += 1
                Continue For
            End Try



            ' Setup UI for progress
            Try
                ProgressBar_SFTPStatus.Style = ProgressBarStyle.Blocks
                ProgressBar_SFTPStatus.Minimum = 0
                ProgressBar_SFTPStatus.Maximum = 100
                ProgressBar_SFTPStatus.Value = 0
            Catch ex As Exception
                MessageBox.Show("Error initializing progress UI: " & ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try

            Dim progress = New Progress(Of DownloadProgress)(Sub(p)
                                                                 Try
                                                                     If p.SFTPTotalBytes > 0 Then
                                                                         Dim percent = CInt((p.SFTPBytesReceived / p.SFTPTotalBytes) * 100)
                                                                         ProgressBar_SFTPStatus.Value = Math.Min(percent, 100)
                                                                         Label_Status_Value.Text = $"Elapsed: {p.SFTPElapsed:hh\:mm\:ss} | ETA: {p.SFTPETA:hh\:mm\:ss} | File {currentIndex} of {totalFiles}: Downloading {fileName}... {percent}% @ {Math.Round(p.SFTPSpeedKbps, 1)} KB/s"
                                                                     End If
                                                                 Catch ex As Exception
                                                                     ' Ignore progress update errors to prevent crashes
                                                                     Debug.WriteLine("Progress Errors:" & ex.Message)
                                                                 End Try
                                                             End Sub)

            ' Perform download
            Dim resultString As String = ""
            Try
                resultString = Await SFTP_DownloadFileAsync(host, username, password, port, remotePath, localPath, progress, token)
            Catch ex As Exception
                MessageBox.Show($"Error downloading file '{fileName}':{vbCrLf}{ex.Message}", "Download Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                failCount += 1
                Continue For
            End Try

            Try
                ProgressBar_SFTPStatus.Value = 0
            Catch
                ' Ignore errors resetting progress
            End Try

            If token.IsCancellationRequested Then
                Label_Status_Value.Text = "Download cancelled"
                cancelCount += 1
                Exit For
            ElseIf resultString.ToLower().Contains("error") Or resultString.ToLower().Contains("fail") Then
                failCount += 1
                If resultString.ToLower().Contains("no such host is known") Then
                    Dim internetConnectionResult As String = Await SFTP_TestConnection(TextBox_SFTP_Host.Text, TextBox_SFTP_Username.Text, TextBox_SFTP_Password.Text, TextBox_SFTP_Port.Text)
                    If internetConnectionResult.ToLower.Contains("error") Then
                        listOfErrorStrings.Add("No Internet Connection Detected - Connection Lost")
                    End If
                Else
                    listOfErrorStrings.Add(resultString)
                End If
            Else
                successCount += 1
            End If
        Next

        ' Final UI state
        Button_SFTP_Download.Enabled = True
        Button_Status_Cancel.Enabled = False
        Label_Status_Value.Text = "Idle"

        ' Summary message
        Dim totalCount = successCount + failCount + cancelCount
        Dim errorList As String = String.Join(vbCrLf, listOfErrorStrings).Replace("ERROR:", "")
        Dim errorListAsMessageString As String = ""
        If String.IsNullOrEmpty(errorList) Then
            errorListAsMessageString = ""
        Else
            errorListAsMessageString = $"Error List:{vbCrLf}{errorList}"
        End If

        Dim summary As String = $"Download Summary:{vbCrLf}" &
                        $"----------------------------------------------------------------------{vbCrLf}" &
                        $"   Processed: {vbTab}{totalCount}{vbCrLf}{vbCrLf}" &
                        $"   Successful:{vbTab}{successCount}{vbCrLf}" &
                        $"   Failed:    {vbTab}{failCount}{vbCrLf}" &
                        $"   Cancelled: {vbTab}{cancelCount}{vbCrLf}" &
                        $"----------------------------------------------------------------------{vbCrLf}{vbCrLf}" &
                        $"{vbCrLf}{errorListAsMessageString}"


        MessageBox.Show(summary, "Download Complete", MessageBoxButtons.OK, MessageBoxIcon.Information)

        Await GetFileFromLocalAsync()
        Await GetFilesFromSFTPAsync()
    End Function






    Private Sub SelectDataGridViewColumn(ByRef passedDataGrid As DataGridView, selectColumnIndex As Integer)
        passedDataGrid.ClearSelection()
        For Each row As DataGridViewRow In passedDataGrid.Rows
            If row.Cells.Count > 0 Then
                row.Cells(0).Selected = True
            End If
        Next
    End Sub



    Private Sub Button_SFTP_DownloadSelectAll_Click(sender As Object, e As EventArgs) Handles Button_SFTP_DownloadSelectAll.Click
        SelectDataGridViewColumn(DataGridView_FileViewer, 0)
    End Sub





    Private Function customCallBack()
        MsgBox("call back fired")
        Return Nothing
    End Function



    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing

    End Sub

    Private Async Sub Button_Local_RefreshPath_Click(sender As Object, e As EventArgs) Handles Button_Local_RefreshPath.Click
        ProgressBar_SFTPStatus.Style = ProgressBarStyle.Marquee
        Await GetFileFromLocalAsync()
        ProgressBar_SFTPStatus.Style = ProgressBarStyle.Blocks
        ProgressBar_SFTPStatus.Value = 0
    End Sub




    Private Sub DataGridView_FileViewerLocal_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_FileViewerLocal.CellContentClick

    End Sub

    Private Async Sub DataGridView_FileViewerLocal_CellDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView_FileViewerLocal.CellDoubleClick
        If e.RowIndex < 0 Then Exit Sub

        Dim selectedRow As DataGridViewRow = DataGridView_FileViewerLocal.Rows(e.RowIndex)
        Dim itemType As String = selectedRow.Cells("LocalType").Value.ToString()
        Dim fileName As String = selectedRow.Cells("localFilename").Value.ToString()

        ' Folder - Open It
        If itemType.Equals("Folder", StringComparison.OrdinalIgnoreCase) Then
            Dim currentPath As String = ComboBox_LocalPath.Text.TrimEnd("/"c)
            Dim newPath As String = $"{currentPath}\{fileName}".Replace("\\", "\")
            ComboBox_LocalPath.Text = newPath

            ProgressBar_LocalStatus.Style = ProgressBarStyle.Marquee
            Await NavigateToPath_Local(newPath)
            ProgressBar_LocalStatus.Style = ProgressBarStyle.Blocks
            ProgressBar_LocalStatus.Value = 0
        End If
    End Sub

    Private Async Sub Button_Local_Navigation_Back_Click(sender As Object, e As EventArgs) Handles Button_Local_Navigation_Back.Click
        If CurrentNavigationIndex_Local > 0 Then
            CurrentNavigationIndex_Local -= 1
            Await NavigateToPath_Local(NavigationStack_Local(CurrentNavigationIndex_Local), triggeredByNavigationButton:=True)
        End If
    End Sub

    Private Async Sub Button_Local_Navigation_Forward_Click(sender As Object, e As EventArgs) Handles Button_Local_Navigation_Forward.Click
        If CurrentNavigationIndex_Local < NavigationStack_Local.Count - 1 Then
            CurrentNavigationIndex_Local += 1
            Await NavigateToPath_Local(NavigationStack_Local(CurrentNavigationIndex_Local), triggeredByNavigationButton:=True)
        End If
    End Sub

    Private Async Sub ComboBox_LocalPath_SelectedIndexChanged(sender As Object, e As EventArgs) Handles ComboBox_LocalPath.SelectedIndexChanged
        Await GetFileFromLocalAsync()
    End Sub

    Private Sub ComboBox_LocalPath_Validating(sender As Object, e As CancelEventArgs) Handles ComboBox_LocalPath.Validating
        CheckIfLocalPathEmpty()
    End Sub


    Private Sub Button_Local_Browse_Click(sender As Object, e As EventArgs) Handles Button_Local_Browse.Click
        Dim dialog As New CommonOpenFileDialog()
        dialog.IsFolderPicker = True
        dialog.Title = "Select a folder"

        ' Set initial directory based on ComboBox_LocalPath.Text
        Dim initialPath As String = ComboBox_LocalPath.Text
        If Directory.Exists(initialPath) Then
            dialog.InitialDirectory = initialPath
        Else
            dialog.InitialDirectory = "C:\"
        End If

        If dialog.ShowDialog() = CommonFileDialogResult.Ok Then
            Dim selectedPath As String = dialog.FileName
            ComboBox_LocalPath.Text = selectedPath
        End If
    End Sub




End Class


